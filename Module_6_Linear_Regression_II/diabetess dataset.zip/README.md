## Instructions
This assignment will take place in a Jupyter Notebook. To open the notebook, select Assignment6.ipynb in the file tree to the left. Everything you need to do the assignment is in the notebook.

For more information on how to use Jupyter, check out [the official Jupyter website](https://jupyter.org).
